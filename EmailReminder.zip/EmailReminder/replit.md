# Ozyde Rental Platform

## Overview

Ozyde is a rental management platform with an automated reminder system for tracking rental returns. The system provides both automated daily email notifications and manual reminder capabilities through an admin dashboard. It helps ensure customers are notified about upcoming rental return deadlines.

## User Preferences

Preferred communication style: Simple, everyday language.

## Recent Changes (October 16, 2025)

### Rental Reminder System Implemented
- **Automated daily email reminders** for rentals due in 1-2 days (runs at 6 AM via cron)
- **Admin dashboard** showing upcoming returns with customer details
- **One-click bulk sending** to all customers with upcoming rentals
- **Individual manual reminders** for specific bookings
- **Complete reminder history** tracking with audit trail
- **Professional HTML email templates** with urgent/warning styling

### Technical Implementation
- PostgreSQL database with compatibility layer for existing mysqli code
- New `reminder_history` table for audit logging
- Three main files: `rental_reminders.php` (dashboard), `send_reminder.php` (sender), `automated_reminders.php` (cron)
- Integrated seamlessly with existing admin authentication system

## System Architecture

### Frontend Architecture

**Admin Panel Interface**
- Server-rendered HTML with progressive enhancement via vanilla JavaScript
- Responsive design using custom CSS with mobile-first approach
- Fixed sidebar navigation (250px width) with collapsible menu for mobile devices
- Flash message system with auto-dismiss functionality (3s timeout)
- Theme toggle with localStorage persistence for dark/light mode preferences

**Design Pattern**: Traditional MPA (Multi-Page Application) with minimal JavaScript for interactivity
- **Rationale**: Simpler deployment, better SEO, reduced client-side complexity
- **Trade-offs**: Full page reloads vs. SPA snappiness, but better initial load performance

### Backend Architecture

**Rental Reminder System**
- Dual-mode operation: Automated cron-based scheduling + manual admin controls
- Automated daily execution at 6 AM via cron jobs
- Smart detection algorithm: Identifies rentals due in 1-2 days (automated) or 1-3 days (manual)
- Deduplication logic: Prevents duplicate reminders sent on the same day

**Email System**
- HTML email templates with urgent/warning styling for visual emphasis
- Bulk sending capability for all eligible customers
- Individual targeted reminders for specific rental instances
- Complete audit trail through database logging (reminder_history table)
- MVP uses PHP mail() function, upgradeable to SendGrid/Resend for production

**Admin Authentication**
- Simple credential-based authentication (username: admin, password: password)
- Session-based authentication pattern
- **Note**: Production deployment requires secure credential management

**Database Architecture**
- PostgreSQL with mysqli compatibility layer for existing code
- Event-sourced reminder history pattern for complete audit trail
- **Rationale**: Maintains compliance tracking, debugging, customer service history
- **Benefits**: Append-only reminder_history table with timestamps

### External Dependencies

**Email Service Provider**
- Current: PHP mail() function (development/MVP)
- Recommended upgrade: SendGrid or Resend for production
- HTML email rendering support
- Delivery status tracking capability for logging

**Scheduled Task Execution**
- Cron job scheduler for automated daily reminders (6 AM execution)
- Script: `admin/automated_reminders.php`
- Server-level or platform-specific cron configuration required

**Database System**
- PostgreSQL with custom mysqli compatibility wrapper
- Schema includes: rentals, customers, products, reminder_history, bookings tables
- Automatic connection via environment variables (DATABASE_URL, PGHOST, etc.)

**Client-Side Dependencies**
- No external JavaScript frameworks or libraries
- Pure CSS implementation (no preprocessors)
- Native browser APIs for DOM manipulation and localStorage

## File Structure

```
admin/
├── rental_reminders.php       # Main dashboard - view upcoming rentals & send reminders
├── send_reminder.php           # Handles bulk and individual email sending
├── automated_reminders.php     # Cron job script for daily automation
├── admin_login.php             # Admin authentication page
├── admindashboard.php          # Main admin dashboard
├── admin_auth.php              # Authentication check middleware
├── config.php                  # Database connection & mysqli compatibility layer
├── header.php                  # Admin navigation (includes Rental Reminders link)
├── footer.php                  # Admin footer
├── image_helpers.php           # Image upload utilities
├── assets/
│   ├── admin.css               # Admin panel styling
│   └── admin.js                # Admin panel JavaScript
└── uploads/                    # Image upload directories

RENTAL_REMINDERS_README.md      # Complete setup & usage documentation
```

## Setup Instructions

### Admin Access
1. Navigate to `/admin`
2. Login: username `admin`, password `password`
3. Access "📧 Rental Reminders" from sidebar

### Automated Reminders (Cron Setup)
```bash
# Add to crontab for daily 6 AM execution
0 6 * * * /usr/bin/php /path/to/admin/automated_reminders.php >> /path/to/logs/cron.log 2>&1
```

### Email Configuration
- MVP uses PHP mail() - works for development
- For production: Integrate SendGrid or Resend
- See RENTAL_REMINDERS_README.md for upgrade instructions

## Database Schema

### Key Tables
- **bookings**: Rental bookings with start/end dates and status
- **users**: Customer information including email addresses
- **products**: Rental products/items
- **reminder_history**: Complete log of all sent reminders (new)
  - Tracks: booking_id, user_id, email, product_name, end_date, days_until_due
  - Type: 'auto' (cron) or 'manual' (admin)
  - Sent by: admin_id (if manual) or NULL (if automated)

## Security Features
- CSRF protection on all forms
- SQL injection prevention via prepared statements
- Session-based admin authentication
- Input sanitization and output escaping
- PostgreSQL compatibility layer with proper parameter binding

## Future Enhancements
- SMS reminders via Twilio
- Multiple reminder schedules (3-day, 1-day, same-day alerts)
- Email delivery tracking with SendGrid webhooks
- Customer preference management (opt-in/opt-out)
- WhatsApp integration
- Reminder analytics dashboard
