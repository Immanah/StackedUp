<?php
// admin_auth.php - Admin authentication check
require_once __DIR__ . '/config.php';

// Check if admin is logged in
if (!isset($_SESSION['admin_id'])) {
    header('Location: admin_login.php');
    exit;
}

// Optional: Load admin details
$admin_id = $_SESSION['admin_id'];
$stmt = $mysqli->prepare("SELECT * FROM admins WHERE id = ? LIMIT 1");
$stmt->bind_param('i', $admin_id);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();

if (!$admin) {
    session_destroy();
    header('Location: admin_login.php');
    exit;
}
