<?php
// image_helpers.php - Image upload and processing helpers

function validate_image_upload($file) {
    if (!isset($file) || $file['error'] === UPLOAD_ERR_NO_FILE) {
        return 'nofile';
    }
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        return 'Upload failed with error code: ' . $file['error'];
    }
    
    $allowed_types = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mime = $finfo->file($file['tmp_name']);
    
    if (!in_array($mime, $allowed_types)) {
        return 'Invalid file type. Only JPEG, PNG, WEBP, and GIF allowed.';
    }
    
    $max_size = 5 * 1024 * 1024; // 5MB
    if ($file['size'] > $max_size) {
        return 'File too large. Maximum 5MB allowed.';
    }
    
    return null; // No error
}

function make_safe_filename($original, $ext) {
    $base = pathinfo($original, PATHINFO_FILENAME);
    $safe = preg_replace('/[^a-z0-9_-]/i', '-', $base);
    $safe = preg_replace('/-+/', '-', $safe);
    $safe = trim($safe, '-');
    $safe = substr($safe, 0, 50);
    return $safe . '-' . uniqid() . '.' . $ext;
}

function create_thumbnail($source, $destination, $max_width, $max_height) {
    $info = getimagesize($source);
    if (!$info) return false;
    
    list($width, $height, $type) = $info;
    
    // Calculate new dimensions
    $ratio = min($max_width / $width, $max_height / $height);
    $new_width = intval($width * $ratio);
    $new_height = intval($height * $ratio);
    
    // Create image resource
    switch ($type) {
        case IMAGETYPE_JPEG:
            $image = imagecreatefromjpeg($source);
            break;
        case IMAGETYPE_PNG:
            $image = imagecreatefrompng($source);
            break;
        case IMAGETYPE_WEBP:
            $image = imagecreatefromwebp($source);
            break;
        default:
            return false;
    }
    
    // Create thumbnail
    $thumb = imagecreatetruecolor($new_width, $new_height);
    imagecopyresampled($thumb, $image, 0, 0, 0, 0, $new_width, $new_height, $width, $height);
    
    // Save thumbnail
    $result = false;
    switch ($type) {
        case IMAGETYPE_JPEG:
            $result = imagejpeg($thumb, $destination, 85);
            break;
        case IMAGETYPE_PNG:
            $result = imagepng($thumb, $destination, 8);
            break;
        case IMAGETYPE_WEBP:
            $result = imagewebp($thumb, $destination, 85);
            break;
    }
    
    imagedestroy($image);
    imagedestroy($thumb);
    
    return $result;
}
