<?php
// config.php - DB connection and helpers
session_start();

// PostgreSQL connection using PDO
try {
    $db = new PDO(
        sprintf("pgsql:host=%s;port=%s;dbname=%s", 
            getenv('PGHOST'), 
            getenv('PGPORT'), 
            getenv('PGDATABASE')
        ),
        getenv('PGUSER'),
        getenv('PGPASSWORD'),
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );
} catch (PDOException $e) {
    die('DB Connect Error: ' . $e->getMessage());
}

// MySQL compatibility layer for existing mysqli code
class MySQLiCompat {
    private $pdo;
    
    public function __construct($pdo) {
        $this->pdo = $pdo;
    }
    
    public function query($sql) {
        try {
            $stmt = $this->pdo->query($sql);
            return new ResultCompat($stmt);
        } catch (PDOException $e) {
            return false;
        }
    }
    
    public function prepare($sql) {
        // Convert ? placeholders for PostgreSQL
        $count = 0;
        $sql = preg_replace_callback('/\?/', function() use (&$count) {
            $count++;
            return '$' . $count;
        }, $sql);
        return new StmtCompat($this->pdo->prepare($sql));
    }
    
    public function real_escape_string($str) {
        return str_replace("'", "''", $str);
    }
    
    public $insert_id;
    
    public function __get($name) {
        if ($name === 'insert_id') {
            return $this->pdo->lastInsertId();
        }
        return null;
    }
}

class StmtCompat {
    private $stmt;
    private $params = [];
    
    public function __construct($stmt) {
        $this->stmt = $stmt;
    }
    
    public function bind_param($types, ...$params) {
        $this->params = $params;
        return true;
    }
    
    public function execute() {
        try {
            return $this->stmt->execute($this->params);
        } catch (PDOException $e) {
            error_log("SQL Error: " . $e->getMessage());
            return false;
        }
    }
    
    public function get_result() {
        return new ResultCompat($this->stmt);
    }
}

class ResultCompat {
    private $stmt;
    
    public function __construct($stmt) {
        $this->stmt = $stmt;
    }
    
    public function fetch_assoc() {
        return $this->stmt->fetch(PDO::FETCH_ASSOC);
    }
    
    public function fetch_all($type = null) {
        return $this->stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    
    public $num_rows;
    
    public function __get($name) {
        if ($name === 'num_rows') {
            return $this->stmt->rowCount();
        }
        return null;
    }
}

// Create mysqli compatibility object
$mysqli = new MySQLiCompat($db);

// Simple CSRF helpers
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(24));
}
function csrf() {
    return $_SESSION['csrf_token'];
}
function check_csrf($token) {
    return isset($token) && hash_equals($_SESSION['csrf_token'], $token);
}

// Escape helper
function e($str) {
    return htmlspecialchars($str, ENT_QUOTES, 'UTF-8');
}
