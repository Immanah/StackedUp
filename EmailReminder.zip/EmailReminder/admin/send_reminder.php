<?php
require_once __DIR__ . '/admin_auth.php';

// Check CSRF
if (!check_csrf($_POST['_csrf'] ?? '')) {
    die('Invalid CSRF token');
}

$sent_count = 0;
$errors = [];

// Function to send reminder email
function send_reminder_email($to, $customer_name, $product_name, $end_date, $days_until_due) {
    $subject = "Reminder: Rental Return Due Soon - {$product_name}";
    
    $urgency = $days_until_due <= 1 ? 'URGENT' : 'Important';
    $due_text = $days_until_due <= 0 ? 'TODAY' : ($days_until_due == 1 ? 'TOMORROW' : "in {$days_until_due} days");
    
    $message = "
    <html>
    <head>
        <style>
            body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
            .container { max-width: 600px; margin: 0 auto; padding: 20px; }
            .header { background: #1f2937; color: white; padding: 20px; text-align: center; }
            .content { background: #f9fafb; padding: 30px; border-radius: 8px; margin: 20px 0; }
            .urgent { background: #fee2e2; border-left: 4px solid #ef4444; padding: 15px; margin: 20px 0; }
            .warning { background: #fef3c7; border-left: 4px solid #f59e0b; padding: 15px; margin: 20px 0; }
            .button { background: #10b981; color: white; padding: 12px 30px; text-decoration: none; display: inline-block; border-radius: 6px; margin: 20px 0; }
            .footer { text-align: center; color: #6b7280; font-size: 0.9rem; margin-top: 30px; }
        </style>
    </head>
    <body>
        <div class='container'>
            <div class='header'>
                <h1>Ozyde Rental Return Reminder</h1>
            </div>
            
            <div class='content'>
                <h2>Hello {$customer_name},</h2>
                
                <div class='" . ($days_until_due <= 1 ? 'urgent' : 'warning') . "'>
                    <strong>{$urgency}:</strong> Your rental return is due {$due_text}!
                </div>
                
                <p><strong>Product:</strong> {$product_name}</p>
                <p><strong>Return Date:</strong> " . date('F j, Y', strtotime($end_date)) . "</p>
                
                <p>Please ensure you return the item by the due date to avoid any late fees.</p>
                
                <p><strong>Return Instructions:</strong></p>
                <ul>
                    <li>Ensure the item is clean and in the same condition as when rented</li>
                    <li>Include all accessories and original packaging</li>
                    <li>Return during our business hours: Mon-Sat 9AM-6PM</li>
                </ul>
                
                <p>If you need to extend your rental or have any questions, please contact us immediately.</p>
                
                <a href='mailto:info@ozyde.com' class='button'>Contact Us</a>
            </div>
            
            <div class='footer'>
                <p>Thank you for choosing Ozyde!</p>
                <p>📧 info@ozyde.com | 📱 0123456789</p>
            </div>
        </div>
    </body>
    </html>
    ";
    
    $headers = [
        'MIME-Version: 1.0',
        'Content-type: text/html; charset=UTF-8',
        'From: Ozyde Rentals <noreply@ozyde.com>',
        'Reply-To: info@ozyde.com',
        'X-Mailer: PHP/' . phpversion()
    ];
    
    // Use PHP's mail() function - in production, use SendGrid or similar
    return mail($to, $subject, $message, implode("\r\n", $headers));
}

// Handle bulk send (all upcoming rentals)
if (isset($_POST['send_all'])) {
    $sql = "
        SELECT 
            b.booking_id,
            b.end_date,
            u.user_id,
            u.first_name,
            u.last_name,
            u.email,
            p.name as product_name,
            EXTRACT(DAY FROM (b.end_date - CURRENT_DATE)) as days_until_due
        FROM bookings b
        JOIN users u ON b.user_id = u.user_id
        JOIN products p ON b.product_id = p.product_id
        WHERE b.status = 'booked'
        AND b.end_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '3 days'
    ";
    
    $result = $mysqli->query($sql);
    
    while ($rental = $result->fetch_assoc()) {
        $customer_name = $rental['first_name'] . ' ' . $rental['last_name'];
        $email_sent = send_reminder_email(
            $rental['email'],
            $customer_name,
            $rental['product_name'],
            $rental['end_date'],
            (int)$rental['days_until_due']
        );
        
        if ($email_sent) {
            // Log the reminder
            $stmt = $mysqli->prepare("
                INSERT INTO reminder_history 
                (booking_id, user_id, email, product_name, end_date, days_until_due, reminder_type, sent_by, email_status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param(
                'iisssisis',
                $rental['booking_id'],
                $rental['user_id'],
                $rental['email'],
                $rental['product_name'],
                $rental['end_date'],
                (int)$rental['days_until_due'],
                'manual',
                $admin_id,
                'sent'
            );
            $stmt->execute();
            $sent_count++;
        } else {
            $errors[] = "Failed to send email to {$rental['email']}";
        }
    }
    
    $_SESSION['flash_success'] = "Successfully sent {$sent_count} reminder emails!";
    if (!empty($errors)) {
        $_SESSION['flash_error'] = implode('<br>', $errors);
    }
    header('Location: rental_reminders.php');
    exit;
}

// Handle individual send
if (isset($_POST['booking_id'])) {
    $booking_id = (int)$_POST['booking_id'];
    
    $stmt = $mysqli->prepare("
        SELECT 
            b.booking_id,
            b.end_date,
            u.user_id,
            u.first_name,
            u.last_name,
            u.email,
            p.name as product_name,
            EXTRACT(DAY FROM (b.end_date - CURRENT_DATE)) as days_until_due
        FROM bookings b
        JOIN users u ON b.user_id = u.user_id
        JOIN products p ON b.product_id = p.product_id
        WHERE b.booking_id = ?
        LIMIT 1
    ");
    $stmt->bind_param('i', $booking_id);
    $stmt->execute();
    $rental = $stmt->get_result()->fetch_assoc();
    
    if ($rental) {
        $customer_name = $rental['first_name'] . ' ' . $rental['last_name'];
        $email_sent = send_reminder_email(
            $rental['email'],
            $customer_name,
            $rental['product_name'],
            $rental['end_date'],
            (int)$rental['days_until_due']
        );
        
        if ($email_sent) {
            // Log the reminder
            $stmt = $mysqli->prepare("
                INSERT INTO reminder_history 
                (booking_id, user_id, email, product_name, end_date, days_until_due, reminder_type, sent_by, email_status)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");
            $stmt->bind_param(
                'iisssisis',
                $rental['booking_id'],
                $rental['user_id'],
                $rental['email'],
                $rental['product_name'],
                $rental['end_date'],
                (int)$rental['days_until_due'],
                'manual',
                $admin_id,
                'sent'
            );
            $stmt->execute();
            
            $_SESSION['flash_success'] = "Reminder email sent to {$rental['email']}!";
        } else {
            $_SESSION['flash_error'] = "Failed to send email to {$rental['email']}";
        }
    } else {
        $_SESSION['flash_error'] = "Booking not found";
    }
    
    header('Location: rental_reminders.php');
    exit;
}

header('Location: rental_reminders.php');
exit;
