<?php
require_once __DIR__ . '/admin_auth.php';
require_once __DIR__ . '/header.php';

// Get some quick stats
$total_products = $mysqli->query("SELECT COUNT(*) as c FROM products")->fetch_assoc()['c'] ?? 0;
$total_orders = $mysqli->query("SELECT COUNT(*) as c FROM orders")->fetch_assoc()['c'] ?? 0;
$total_users = $mysqli->query("SELECT COUNT(*) as c FROM users")->fetch_assoc()['c'] ?? 0;
$active_bookings = $mysqli->query("SELECT COUNT(*) as c FROM bookings WHERE status = 'booked'")->fetch_assoc()['c'] ?? 0;
$upcoming_returns = $mysqli->query("SELECT COUNT(*) as c FROM bookings WHERE status = 'booked' AND end_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '3 days'")->fetch_assoc()['c'] ?? 0;
?>

<style>
.dashboard-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 1.5rem;
    margin-bottom: 2rem;
}
.stat-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}
.stat-value {
    font-size: 2.5rem;
    font-weight: 700;
    color: #1f2937;
    margin: 0.5rem 0;
}
.stat-label {
    color: #6b7280;
    font-size: 0.9rem;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}
.stat-icon {
    font-size: 2rem;
    margin-bottom: 0.5rem;
}
.quick-actions {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 1rem;
    margin-top: 2rem;
}
.action-btn {
    display: block;
    background: #667eea;
    color: white;
    padding: 1rem;
    text-align: center;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 600;
    transition: all 0.2s;
}
.action-btn:hover {
    background: #5568d3;
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
}
</style>

<div class="card">
    <h2>Welcome, <?= e($admin['name']) ?>! 👋</h2>
    <p style="color: #6b7280; margin-top: 0.5rem;">Here's what's happening with your store today.</p>
</div>

<div class="dashboard-grid">
    <div class="stat-card">
        <div class="stat-icon">📦</div>
        <div class="stat-value"><?= $total_products ?></div>
        <div class="stat-label">Total Products</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">🛒</div>
        <div class="stat-value"><?= $total_orders ?></div>
        <div class="stat-label">Total Orders</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">👥</div>
        <div class="stat-value"><?= $total_users ?></div>
        <div class="stat-label">Total Customers</div>
    </div>
    
    <div class="stat-card">
        <div class="stat-icon">🔖</div>
        <div class="stat-value"><?= $active_bookings ?></div>
        <div class="stat-label">Active Rentals</div>
    </div>
    
    <div class="stat-card" style="border-left: 4px solid #ef4444;">
        <div class="stat-icon">⏰</div>
        <div class="stat-value" style="color: #ef4444;"><?= $upcoming_returns ?></div>
        <div class="stat-label">Returns Due (3 Days)</div>
    </div>
</div>

<div class="card">
    <h3>Quick Actions</h3>
    <div class="quick-actions">
        <a href="product_edit.php" class="action-btn">➕ Add Product</a>
        <a href="orders_list.php" class="action-btn">📋 View Orders</a>
        <a href="rental_reminders.php" class="action-btn" style="background: #10b981;">📧 Rental Reminders</a>
        <a href="messages_list.php" class="action-btn" style="background: #f59e0b;">💬 Messages</a>
    </div>
</div>

<?php require_once __DIR__ . '/footer.php'; ?>
