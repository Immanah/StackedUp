<?php
require_once __DIR__ . '/admin_auth.php';
require_once __DIR__ . '/header.php';

// Get upcoming rentals (due in next 3 days)
$sql = "
    SELECT 
        b.booking_id,
        b.end_date,
        b.status,
        u.user_id,
        u.first_name,
        u.last_name,
        u.email,
        u.phone,
        p.product_id,
        p.name as product_name,
        EXTRACT(DAY FROM (b.end_date - CURRENT_DATE)) as days_until_due
    FROM bookings b
    JOIN users u ON b.user_id = u.user_id
    JOIN products p ON b.product_id = p.product_id
    WHERE b.status = 'booked'
    AND b.end_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '3 days'
    ORDER BY b.end_date ASC
";

$upcoming_rentals = $mysqli->query($sql);
$rental_count = $upcoming_rentals->num_rows;

// Get recently sent reminders (last 7 days)
$history_sql = "
    SELECT 
        rh.*,
        u.first_name,
        u.last_name,
        a.name as sent_by_name
    FROM reminder_history rh
    JOIN users u ON rh.user_id = u.user_id
    LEFT JOIN admins a ON rh.sent_by = a.id
    WHERE rh.sent_at >= CURRENT_DATE - INTERVAL '7 days'
    ORDER BY rh.sent_at DESC
    LIMIT 50
";

$reminder_history = $mysqli->query($history_sql);
?>

<style>
.rental-card {
    background: white;
    border-radius: 8px;
    padding: 1.5rem;
    margin-bottom: 1rem;
    border-left: 4px solid #3b82f6;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.rental-card.urgent {
    border-left-color: #ef4444;
    background: #fef2f2;
}

.rental-card.warning {
    border-left-color: #f59e0b;
    background: #fffbeb;
}

.rental-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 1rem;
}

.customer-info {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 1rem;
    margin-top: 1rem;
    padding-top: 1rem;
    border-top: 1px solid #e5e7eb;
}

.info-item {
    display: flex;
    flex-direction: column;
}

.info-label {
    font-size: 0.75rem;
    color: #6b7280;
    text-transform: uppercase;
    letter-spacing: 0.05em;
}

.info-value {
    font-size: 0.9rem;
    font-weight: 600;
    color: #1f2937;
    margin-top: 0.25rem;
}

.due-badge {
    padding: 0.5rem 1rem;
    border-radius: 6px;
    font-weight: 600;
    font-size: 0.9rem;
}

.due-tomorrow {
    background: #fee2e2;
    color: #991b1b;
}

.due-2days {
    background: #fef3c7;
    color: #92400e;
}

.due-3days {
    background: #dbeafe;
    color: #1e40af;
}

.send-all-btn {
    background: #10b981;
    color: white;
    border: none;
    border-radius: 8px;
    padding: 1rem 2rem;
    font-size: 1.1rem;
    font-weight: 600;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
    transition: all 0.2s;
}

.send-all-btn:hover {
    background: #059669;
    transform: translateY(-1px);
    box-shadow: 0 4px 12px rgba(16, 185, 129, 0.3);
}

.send-all-btn:disabled {
    background: #9ca3af;
    cursor: not-allowed;
}

.history-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 1rem;
}

.history-table th,
.history-table td {
    padding: 0.75rem;
    text-align: left;
    border-bottom: 1px solid #e5e7eb;
}

.history-table th {
    background: #f9fafb;
    font-weight: 600;
    color: #374151;
}

.type-badge {
    padding: 0.25rem 0.5rem;
    border-radius: 4px;
    font-size: 0.75rem;
    font-weight: 600;
}

.type-auto {
    background: #dbeafe;
    color: #1e40af;
}

.type-manual {
    background: #fef3c7;
    color: #92400e;
}
</style>

<div class="card">
    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem;">
        <div>
            <h3 style="margin: 0;">📧 Rental Return Reminders</h3>
            <p style="margin: 0.5rem 0 0 0; color: #6b7280;">
                Manage automated and manual reminder emails for upcoming rental returns
            </p>
        </div>
        <?php if ($rental_count > 0): ?>
            <form method="post" action="send_reminder.php" style="margin: 0;">
                <input type="hidden" name="_csrf" value="<?= csrf() ?>">
                <input type="hidden" name="send_all" value="1">
                <button type="submit" class="send-all-btn" onclick="return confirm('Send reminder emails to all <?= $rental_count ?> customers with rentals due in 1-3 days?')">
                    📧 Send Reminders to All <?= $rental_count ?> Customers
                </button>
            </form>
        <?php endif; ?>
    </div>

    <!-- Upcoming Rentals Section -->
    <div style="margin-bottom: 3rem;">
        <h4>📅 Upcoming Returns (Next 3 Days)</h4>
        
        <?php if ($rental_count > 0): ?>
            <?php while ($rental = $upcoming_rentals->fetch_assoc()): 
                $days = (int)$rental['days_until_due'];
                $urgency_class = $days <= 1 ? 'urgent' : ($days <= 2 ? 'warning' : '');
                $badge_class = $days <= 1 ? 'due-tomorrow' : ($days <= 2 ? 'due-2days' : 'due-3days');
                $due_text = $days <= 0 ? 'DUE TODAY' : ($days == 1 ? 'Due Tomorrow' : "Due in {$days} days");
            ?>
                <div class="rental-card <?= $urgency_class ?>">
                    <div class="rental-header">
                        <div>
                            <h4 style="margin: 0; font-size: 1.1rem;"><?= e($rental['product_name']) ?></h4>
                            <small style="color: #6b7280;">Booking #<?= e($rental['booking_id']) ?></small>
                        </div>
                        <span class="due-badge <?= $badge_class ?>"><?= $due_text ?></span>
                    </div>
                    
                    <div class="customer-info">
                        <div class="info-item">
                            <span class="info-label">Customer</span>
                            <span class="info-value"><?= e($rental['first_name'] . ' ' . $rental['last_name']) ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Email</span>
                            <span class="info-value"><?= e($rental['email']) ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Phone</span>
                            <span class="info-value"><?= e($rental['phone'] ?: 'N/A') ?></span>
                        </div>
                        <div class="info-item">
                            <span class="info-label">Return Date</span>
                            <span class="info-value"><?= date('M j, Y', strtotime($rental['end_date'])) ?></span>
                        </div>
                        <div class="info-item" style="grid-column: span 2;">
                            <form method="post" action="send_reminder.php" style="margin-top: 0.5rem;">
                                <input type="hidden" name="_csrf" value="<?= csrf() ?>">
                                <input type="hidden" name="booking_id" value="<?= e($rental['booking_id']) ?>">
                                <button type="submit" class="btn" style="background: #3b82f6; padding: 0.5rem 1rem;">
                                    Send Individual Reminder
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div style="text-align: center; padding: 3rem; background: #f9fafb; border-radius: 8px;">
                <div style="font-size: 3rem; margin-bottom: 1rem;">✅</div>
                <h4 style="color: #6b7280;">No Upcoming Returns</h4>
                <p style="color: #9ca3af;">No rentals are due in the next 3 days</p>
            </div>
        <?php endif; ?>
    </div>

    <!-- Reminder History Section -->
    <div>
        <h4>📋 Recent Reminder History (Last 7 Days)</h4>
        
        <?php if ($reminder_history->num_rows > 0): ?>
            <table class="history-table">
                <thead>
                    <tr>
                        <th>Date Sent</th>
                        <th>Customer</th>
                        <th>Product</th>
                        <th>Return Date</th>
                        <th>Days Until Due</th>
                        <th>Type</th>
                        <th>Sent By</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($history = $reminder_history->fetch_assoc()): ?>
                        <tr>
                            <td><?= date('M j, g:i A', strtotime($history['sent_at'])) ?></td>
                            <td><?= e($history['first_name'] . ' ' . $history['last_name']) ?></td>
                            <td><?= e($history['product_name']) ?></td>
                            <td><?= date('M j, Y', strtotime($history['end_date'])) ?></td>
                            <td><?= e($history['days_until_due']) ?> days</td>
                            <td>
                                <span class="type-badge type-<?= e($history['reminder_type']) ?>">
                                    <?= ucfirst($history['reminder_type']) ?>
                                </span>
                            </td>
                            <td><?= e($history['sent_by_name'] ?: 'System') ?></td>
                            <td><?= e(ucfirst($history['email_status'])) ?></td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div style="text-align: center; padding: 2rem; background: #f9fafb; border-radius: 8px;">
                <p style="color: #9ca3af;">No reminders sent in the last 7 days</p>
            </div>
        <?php endif; ?>
    </div>
</div>

<script>
// Auto-refresh every 5 minutes to show updated rental status
setTimeout(() => {
    location.reload();
}, 5 * 60 * 1000);
</script>

<?php require_once __DIR__ . '/footer.php'; ?>
