# 📧 Rental Reminder System - Setup & Usage Guide

## Overview

Automated and manual rental return reminder system for Ozyde platform. Sends email reminders to customers with upcoming rental returns.

## Features

✅ **Automated Daily Emails** - Automatically sends reminders at 6 AM for rentals due in 1-2 days  
✅ **Manual Control** - Admin dashboard to manually send reminders anytime  
✅ **Bulk Sending** - One-click to send reminders to all customers with upcoming returns  
✅ **Individual Sending** - Manual reminder for specific customers  
✅ **Reminder History** - Track all sent reminders with full details  
✅ **Professional Email Templates** - HTML emails with urgent/warning styling  
✅ **Complete Logging** - All reminders logged to database for auditing

## Quick Start

### 1. Access the System

1. Open the admin panel: `http://your-domain.com/admin`
2. Login with credentials:
   - Username: `admin`
   - Password: `password`
3. Click "📧 Rental Reminders" in the sidebar

### 2. Send Reminders Manually

**Bulk Send (All Customers):**
- Click the green "📧 Send Reminders to All X Customers" button
- Confirms before sending
- Sends to all customers with rentals due in 1-3 days

**Individual Send:**
- Find the specific rental in the list
- Click "Send Individual Reminder" button
- Instant confirmation and logging

### 3. View Reminder History

- Scroll to "Recent Reminder History" section
- See last 7 days of sent reminders
- Track: Date, Customer, Product, Type (Auto/Manual), Status

## Automated Daily Reminders

### How It Works

1. **Daily Execution**: Runs every day at 6 AM (configured via cron)
2. **Smart Detection**: Finds rentals due in 1-2 days that haven't been reminded today
3. **Auto-Send**: Emails customers automatically
4. **Logging**: Records everything to reminder_history table

### Setup Cron Job

#### Option 1: Linux/Mac Cron

```bash
# Open crontab editor
crontab -e

# Add this line to run daily at 6 AM
0 6 * * * /usr/bin/php /path/to/admin/automated_reminders.php >> /path/to/logs/cron.log 2>&1
```

#### Option 2: Replit Deployments

Replit deployments support cron jobs. The system is ready - just deploy and the automation will run.

#### Option 3: Manual Test

```bash
# Test the automated script manually
php admin/automated_reminders.php
```

## Email System

### Current Setup (MVP)

- Uses PHP's built-in `mail()` function
- Works for development and small-scale production
- Emails may go to spam without proper SMTP setup

### Upgrade to Production Email Service

For better deliverability, integrate with:

#### SendGrid (Recommended)
```php
// In send_reminder.php, replace mail() with:
$sg = new \SendGrid(getenv('SENDGRID_API_KEY'));
$email = new \SendGrid\Mail\Mail();
// Configure and send...
```

#### Resend
```php
// Use Resend PHP SDK
$resend = Resend::client(getenv('RESEND_API_KEY'));
$resend->emails->send([...]);
```

## Database Schema

### reminder_history Table

Stores all sent reminders for auditing:

```sql
CREATE TABLE reminder_history (
  reminder_id SERIAL PRIMARY KEY,
  booking_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  email VARCHAR(150) NOT NULL,
  product_name VARCHAR(150),
  end_date DATE NOT NULL,
  days_until_due INTEGER,
  reminder_type VARCHAR(20) DEFAULT 'auto',  -- 'auto' or 'manual'
  sent_by INTEGER,  -- admin_id if manual, NULL if auto
  sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  email_status VARCHAR(20) DEFAULT 'sent'
);
```

## File Structure

```
admin/
├── rental_reminders.php       # Main dashboard (view & send)
├── send_reminder.php           # Bulk/individual sender
├── automated_reminders.php     # Cron job script
├── admin_auth.php              # Authentication check
├── config.php                  # Database connection
├── header.php                  # Admin navigation (updated)
└── footer.php                  # Admin footer
```

## Troubleshooting

### Emails Not Sending

1. **Check PHP mail() configuration**:
   ```bash
   php -i | grep sendmail
   ```

2. **Test mail function**:
   ```php
   php -r "mail('test@example.com', 'Test', 'Body');"
   ```

3. **Check logs**:
   - Workflow logs in Replit
   - `/tmp/logs/reminder_cron.log` for automated runs

### Database Connection Issues

1. Verify PostgreSQL environment variables are set:
   - `DATABASE_URL`
   - `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD`, `PGDATABASE`

2. Test database connection:
   ```bash
   php -r "require 'admin/config.php'; echo 'Connected!';"
   ```

### Reminders Not Showing

1. Check if bookings exist:
   ```sql
   SELECT * FROM bookings 
   WHERE status = 'booked' 
   AND end_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '3 days';
   ```

2. Verify user emails are set:
   ```sql
   SELECT * FROM users WHERE email IS NOT NULL;
   ```

## Customization

### Change Reminder Threshold

Edit `rental_reminders.php` and `automated_reminders.php`:

```php
// Current: 3 days for dashboard, 2 days for automation
AND b.end_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '3 days'

// Change to 5 days:
AND b.end_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '5 days'
```

### Customize Email Template

Edit the email HTML in `send_reminder.php` and `automated_reminders.php` (function `send_reminder_email`):

```php
$message = "
<html>
  <!-- Your custom template here -->
</html>
";
```

### Change Automation Schedule

```bash
# Run at 8 AM instead of 6 AM
0 8 * * * /usr/bin/php /path/to/automated_reminders.php

# Run twice daily (6 AM and 6 PM)
0 6,18 * * * /usr/bin/php /path/to/automated_reminders.php
```

## Support & Maintenance

### Monitoring

- Check reminder_history table daily for sent count
- Monitor email_status for failures
- Review logs for any errors

### Regular Tasks

- **Weekly**: Review reminder history, ensure automation is running
- **Monthly**: Verify email deliverability, consider upgrading to SMTP
- **Quarterly**: Clean old reminder_history records (keep last 90 days)

## Security Notes

✅ CSRF Protection - All forms use CSRF tokens  
✅ SQL Injection Prevention - Prepared statements for all queries  
✅ Authentication Required - Admin login required for all actions  
✅ Input Sanitization - Email addresses and user data properly escaped

## Future Enhancements

- SMS reminders (Twilio integration)
- Multiple reminder schedules (3-day, 1-day, same-day)
- Email delivery tracking with SendGrid webhooks
- Customer preference management (opt-in/opt-out)
- WhatsApp reminders integration
- Reminder analytics dashboard

---

**Need Help?** Check the code comments or contact your development team.
